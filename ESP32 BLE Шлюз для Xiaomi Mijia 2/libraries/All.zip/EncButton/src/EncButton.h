#pragma once
#include <Arduino.h>

#include "core/VirtButton.h"
#include "core/VirtEncoder.h"
#include "core/VirtEncButton.h"
#include "core/Button.h"
#include "core/Encoder.h"
#include "core/EncButton.h"